#! /usr/bin/python
# -*- coding: utf-8 -*-

import os

cmd = "cmake -G \"Unix Makefiles\" -S . -B build"
os.system(cmd)
