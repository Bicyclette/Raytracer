#ifndef COLOR_HPP
#define COLOR_HPP

const float LIGHT_GREY[4] = {0.749f, 0.737f, 0.706f, 1.0f};
const float SAPHIRE_BLUE[4] = {0.059f, 0.322f, 0.729f, 1.0f};

#endif
